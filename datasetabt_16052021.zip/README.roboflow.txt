
Aksara Prasidang1 - v1 2021-04-29 4:27pm
==============================

This dataset was exported via roboflow.ai on May 1, 2021 at 2:34 AM GMT

It includes 1927 images.
Pieces are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


